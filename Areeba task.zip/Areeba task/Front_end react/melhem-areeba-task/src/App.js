import React from "react";
import { Container, Row, Form, FormGroup, FormControl, FormLabel, Button, Alert, Table } from 'react-bootstrap';
import axios from 'axios';
class App extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			name: "",
			address: "",
            phone:"",
			records: [],
			showAlert: false,
			alertMsg: "",
			alertType: "success",
			id: "",
			update: false,
		};
	}

	handleChange = (evt) => {
		this.setState({
			[evt.target.name]: evt.target.value,
		});
	};

	componentWillMount() {
		this.fetchAllRecords();
	}

	// add a record
	addRecord = () => {
    // const headers = {
    //   "Access-Control-Allow-Origin": "*",
    //   'Content-Type': 'application/json',
    // }
    
    // let axiosConfig = {
    //   headers: {
    //       "Access-Control-Allow-Origin": "*",
    //       "Access-Control-Allow-Headers":"Origin, X-Requested-With, Content-Type, Accept"
	// 	,
	// 	"Access-Control-Allow-Methods" : "GET, POST, OPTIONS, HEAD",
    //   }
    // };

    // var body = { name: this.state.name,phone: this.state.phone , address: this.state.address  };
    //  axios.post(`http://localhost:9191/customer/addCustomer/`,  body, axiosConfig)
    
    // .then(res => {
    //   console.log(res);
    //   console.log(res.data);
   // })
//    var headers = new Headers();
//    headers.append('Content-Type', 'application/json');
//    headers.append('Accept', 'application/json');
//    headers.append('Access-Control-Allow-Origin', 'http://localhost:9191');
//    headers.append('Access-Control-Allow-Methods', '*');
//    headers.append('Access-Control-Allow-Headers', 'http://localhost:9191');







   // var body =  JSON.stringify({ name: this.state.name, phone: this.state.phone , address: this.state.address  });

	


	fetch("http://localhost:9191/customer/addCustomer?name="+this.state.name+"&phone="+this.state.phone +"&address="+this.state.address , {
			method: "POST",
			
			//headers: headers,
			// mode:"no-cors",
			
	})
		.then((response) => response.json())
			.then((result) => {
				console.log(result);
				if(result.code===2){
				this.setState({
					name: "",
					address: "",
                    phone: "",
					showAlert: true,
					alertMsg: result.description,
					alertType: "success",
				});
			}else   {
				this.setState({
					
					showAlert: true,
					alertMsg: result.description,
					alertType: "danger",
				});
			}
			this.fetchAllRecords();
		})
		.catch((error) => console.log("error", error));










		// var myHeaders = new Headers();
		// myHeaders.append("Content-Type", "application/json");

		// var body = JSON.stringify({ name: this.state.name, address: this.state.address });
		// fetch("http://localhost:8000/api/create", {
		// 	method: "POST",
		// 	headers: myHeaders,
		// 	body: body,
		// })
		// 	.then((response) => response.json())
		// 	.then((result) => {
		// 		console.log(result);
		// 		this.setState({
		// 			name: "",
		// 			address: "",
    //       phone: "",
		// 			showAlert: true,
		// 			alertMsg: result.response,
		// 			alertType: "success",
		// 		});
		// 	});
	};

	// fetch All Records
	fetchAllRecords = () => {

    
    axios.get('http://localhost:9191/customer/getAllCustomers')
    .then(res => {
      const records = res.data;
      this.setState({ records });
    })
    .catch((error) => console.log("error", error));

		// var headers = new Headers();
		// headers.append("Content-Type", "application/json");
    // headers.append("Access-Control-Allow-Origin", "*");
    // headers.append("Access-Control-Allow-Headers", "X-Requested-With");
   
		// fetch("http://localhost:9191/customer/getAllCustomers",{
		// 	method: "GET",
    //   mode: 'no-cors',
		// 	headers: headers,
		// })
		// 	.then((response) => response.json())
		// 	.then((result) => {
		// 		console.log("result", result);
        
		// 		this.setState({
		// 			records: result.response,
    
		// 		});
		// 	})
		// 	.catch((error) => console.log("nfokhooooooooo", error));
	
    };

	// view single data to edit
	editRecord = (id,name,address,phone) => {
		
			
				this.setState({
					id: id,
					update: true,
					name: name,
					address: address,
					phone: phone,
				});
	
		
	};




	// update record
	updateRecord = () => {
		
		fetch("http://localhost:9191/customer/updateById?id="+this.state.id+"&name="+this.state.name+"&phone="+this.state.phone +"&address="+this.state.address, {
			method: "POST",
	
			
		})
			.then((response) => response.json()
			
			)
			.then((result) => {
				if(result.code===2){
				this.setState({

					showAlert: true,
					alertMsg: result.description,
					alertType: "success",
					update: false,
					 id: "",
					name: "",
					address: "",
                     phone:"",
				});
			}else{
				this.setState({

					showAlert: true,
					alertMsg: result.description,
					alertType: "danger",
					update: false,
					
				});
				
			}
				this.fetchAllRecords();
			})
			.catch((error) => console.log("error", error));
	};

	// delete a record
	deleteRecord = (id) => {
		fetch("http://localhost:9191/customer/deleteById/" + id, {
			method: "POST",
		})
			.then((response) => response.json())
			.then((result) => {
				this.setState({
					showAlert: true,
					alertMsg: result.response,
					alertType: "danger",
				});
				this.fetchAllRecords();
			})
			.catch((error) => console.log("error", error));
	};
	render() {
		return (
			<div>
				<Container>
				<h1>task by Melhem Shoker</h1>
					{this.state.showAlert === true ? (
						<Alert
							variant={this.state.alertType}
							onClose={() => {
								this.setState({
									showAlert: false,
								});
							}}
							dismissible
						>
							<Alert.Heading>{this.state.alertMsg}</Alert.Heading>
						</Alert>
					) : null}

					{/* All Records */}
					<Row>
						<Table striped bordered hover size="sm">
							<thead>
								<tr>
									<th>id</th>
									<th>Name</th>
									<th>address</th>
                  <th>phone number</th>
									<th colSpan="2">Actions</th>
								</tr>
							</thead>
							<tbody>
								{this.state.records.map((record) => {
									return (
										<tr>
											<td>{record.id}</td>
											<td>{record.name}</td>
											<td>{record.address}</td>
                      <td>{record.phone}</td>

											<td>
												<Button variant="info" onClick={() => this.editRecord(record.id,record.name,record.address,record.phone)}>
													Edit
												</Button>
											</td>
											<td>
												<Button variant="danger" onClick={() => this.deleteRecord(record.id)}>
													Delete
												</Button>
											</td>
										</tr>
									);
								})}
							</tbody>
						</Table>
					</Row>

					{/* Insert Form */}
					<Row>
						<Form>
							<FormGroup>
								<FormLabel>Enter the name</FormLabel>
								<FormControl type="text" name="name" placeholder="Enter the name" onChange={this.handleChange} value={this.state.name}></FormControl>
							</FormGroup>
							<FormGroup>
								<FormLabel>Enter the address</FormLabel>
								<FormControl type="text" name="address" value={this.state.address} onChange={this.handleChange} placeholder="Enter the address"></FormControl>
							</FormGroup>
              <FormGroup>
              <FormLabel>Enter the phone number (with country code ex :961)</FormLabel>
              <FormControl type="text" name="phone" value={this.state.phone} onChange={this.handleChange} placeholder="Enter the phone number"></FormControl>
            </FormGroup>
							{this.state.update === true ? <Button onClick={this.updateRecord}>update</Button> : <Button onClick={this.addRecord}>Save</Button>}
						</Form>
					</Row>
				</Container>
			</div>
		);
	}
}
export default App;