package com.melhem.areeba.customer.controller;


import com.melhem.areeba.customer.requests.CustomerAddRequest;
import com.melhem.areeba.customer.requests.CustomerUpdateRequest;
import com.melhem.areeba.customer.responses.CustomerResponse;
import com.melhem.areeba.customer.responses.Resp;
import com.melhem.areeba.customer.service.CustomerService;
import lombok.extern.slf4j.Slf4j;
import lombok.extern.slf4j.XSlf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value="customer")
@Slf4j
public class CustomerController {
    @Autowired
    CustomerService customerService;
    @GetMapping("/getAllCustomers")

    private  ResponseEntity<List<CustomerResponse>>  getAllCustomers(){
        List<CustomerResponse> customerResponseList = customerService.getAllCustomers();
         return new ResponseEntity<>(customerResponseList, HttpStatus.OK);
    }

    @PostMapping("/deleteById/{id}")

    private  ResponseEntity<Void>  deleteById(@PathVariable("id")Long id){
        ResponseEntity <Void> responseEntity =  customerService.deleteById( id);
        return  responseEntity;
    }
    @PostMapping("/updateById")

    private  ResponseEntity<Resp>  updateById(@RequestParam(name = "id")  Long id ,@RequestParam(name = "name")  String name ,@RequestParam(name = "address")  String address,@RequestParam(name = "phone")  String phone){
        CustomerUpdateRequest   customerUpdateRequest = new CustomerUpdateRequest();
        customerUpdateRequest.setId(id);
        customerUpdateRequest.setName(name);
        customerUpdateRequest.setAddress(address);
        customerUpdateRequest.setPhone(phone);

        try {
            Resp resp = customerService.updateById(customerUpdateRequest);
            return  new ResponseEntity<>(resp ,HttpStatus.OK);
        }
        catch(Exception exception){
          return   new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
        }


    }
    @PostMapping("/addCustomer")

    private  ResponseEntity<Resp>  addCustomer(@RequestParam(name = "name")  String name ,@RequestParam(name = "address")  String address,@RequestParam(name = "phone")  String phone){
       log.info("/////////////////////");
        CustomerAddRequest customerAddRequest = new CustomerAddRequest();
        customerAddRequest.setName(name);
        customerAddRequest.setAddress(address);
        customerAddRequest.setPhone(phone);
        log.info(customerAddRequest.getName());
        try {

            Resp resp = customerService.addCustomer(customerAddRequest);
            return  new ResponseEntity<>(resp ,HttpStatus.OK);
        }
        catch(Exception exception){
            return   new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
        }


    }


}
