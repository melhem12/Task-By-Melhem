package com.melhem.areeba.validator.services;

import com.melhem.areeba.validator.response.ValidationResponse;
import org.springframework.boot.jackson.JsonObjectDeserializer;
import org.springframework.stereotype.Service;
import java.io.IOException;
import org.apache.http.client.fluent.*;
import org.json.JSONObject;
@Service

public class Validate {
    private  Content makeAbstractRequest(String phone ) {

        try {

            Content content = Request.Get("https://phonevalidation.abstractapi.com/v1/?api_key=c166d60967b2482e8f3da556ec7e3b99&phone="+phone)

                    .execute().returnContent();

            System.out.println(content);
       return  content;
        }


        catch (IOException error) { System.out.println(error);
        return  null ;
        }
    }

    public ValidationResponse check(String phoneNumber) {
     Content c=   makeAbstractRequest(phoneNumber);
        JSONObject jsonObject = new JSONObject(c.asString());
String operator= jsonObject.getString("carrier");
ValidationResponse validationResponse= new ValidationResponse();
validationResponse.setOperatorName(operator);
        JSONObject countryObject= jsonObject.getJSONObject("country");
        String countryName= countryObject.getString("name");
        String countryCode= countryObject.getString("code");
        validationResponse.setCountryCode(countryCode);

        validationResponse.setCountryName(countryName);
        return validationResponse;


    }
}
